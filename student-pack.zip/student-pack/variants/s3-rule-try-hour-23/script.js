/* TRY · slide s3-rule · the clock is replaced by the number 23 so the room can see 'Closed now' in daytime. Change 23 to 10, 11, 21, 22 and predict before each save. */
/* script.js — runs on every page */

/* ===== 1. The opening-hours rule (§3) ===== */

function isOpen(hour) {
  return hour >= 11 && hour < 22;
}

/* ===== 2. Show today's status in the header (§3) ===== */

const openStatus = document.querySelector("#open-status");
const hourNow = 23;

if (isOpen(hourNow)) {
  openStatus.textContent = "Open now · until 22:00";
  openStatus.classList.add("open");
} else {
  openStatus.textContent = "Closed now · opens at 11:00";
  openStatus.classList.add("closed");
}
