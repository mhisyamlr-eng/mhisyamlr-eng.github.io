/* EXHIBIT · NEVER DO THIS · slide s7-cannot · a "secret" checked in the browser.
   Anyone can open this file (Ctrl+U, then click it; or DevTools → Sources) and read the code. */

function voucherIsValid(code) {
  return code === "LEMON50";
}
