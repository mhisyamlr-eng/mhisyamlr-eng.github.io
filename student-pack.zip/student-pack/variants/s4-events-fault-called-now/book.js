/* BROKEN ON PURPOSE · slide s4-name-not-call · showSeatingNote() with brackets runs ONCE, at load, and hands addEventListener nothing. No error anywhere; clicking Outdoor does nothing. */
/* book.js — book.html only */

/* ===== 1. Outdoor note: respond to a click (§4) ===== */

const indoorInput = document.querySelector("#indoor");
const outdoorInput = document.querySelector("#outdoor");
const seatingNote = document.querySelector("#seating-note");

function showSeatingNote() {
  if (outdoorInput.checked) {
    seatingNote.hidden = false;
  } else {
    seatingNote.hidden = true;
  }
}

indoorInput.addEventListener("click", showSeatingNote());
outdoorInput.addEventListener("click", showSeatingNote());

/* ===== 2. Characters left: respond to typing (§4) ===== */

const requestsInput = document.querySelector("#requests");
const requestsCount = document.querySelector("#requests-count");

function updateCount() {
  const left = 200 - requestsInput.value.length;
  requestsCount.textContent = left + " characters left";
}

requestsInput.addEventListener("input", updateCount);
