# Activity 1 · Write the rule (12 minutes, groups of three)

Three business rules from Little Lemon. Each becomes one small function.

1. Open `index.html` in this folder, then open the Console (F12 → Console).
2. In `rules.js`, write the body of each function. Save. Refresh the page.
3. **Predict first, then run.** Write your prediction in the table, then type the call into the Console.

| Call | Predict | Console says |
|---|---|---|
| `needsPhoneCall(8)` | | |
| `needsPhoneCall(9)` | | |
| `priceLabel(10)` | | |
| `totalGuests(2, 1)` | | |
| `totalGuests("2", "1")` | | |

4. One of the five surprised you. Fix that function so it gives the right answer for both calls.

Fast finisher: write `isLunchTime(hour)` — lunch is from 11:00 up to, but not including, 15:00.
