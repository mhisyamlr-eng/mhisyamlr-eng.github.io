/* activity 1 · slide: act1 · indicators 1, 2 · starter */
/* Write each rule as a function. Save, refresh, then call it in the Console. */

/* Rule 1. A party of more than 8 guests must phone the restaurant.
   needsPhoneCall(9) should give true. needsPhoneCall(8) should give false. */
function needsPhoneCall(party) {
  /* your code here */
}

/* Rule 2. Every price is shown with a dollar sign in front.
   priceLabel(10) should give "$10". */
function priceLabel(price) {
  /* your code here */
}

/* Rule 3. Total guests is adults plus children.
   totalGuests(2, 1) should give 3.
   Then call totalGuests("2", "1") — that is how a form hands you the numbers. */
function totalGuests(adults, children) {
  /* your code here */
}
