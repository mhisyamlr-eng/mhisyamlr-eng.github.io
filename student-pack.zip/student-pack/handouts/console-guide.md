# Console guide — DG234507 Week 5

The Console is a prompt inside your browser. You type one line of JavaScript, press Enter, and it answers at once. It is the fastest way to ask a page a question, and the first place a broken script tells you what is wrong.

## 1. Open it (Chrome)

| System | Keys |
|---|---|
| Windows / Linux | **F12**, or **Ctrl + Shift + J** |
| Mac | **Cmd + Option + J** |

Then click the **Console** tab. The prompt is the `>` at the bottom. Type a line, press **Enter**.

## 2. Try three lines

```
11 < 22
"Little Lemon"
document.querySelector("h1")
```

The answers: `true`, `'Little Lemon'`, and the heading itself. Hover over the heading in the answer and it lights up on the page.

## 3. Read a red error

A red line has three parts. Read them in this order:

| Part | Example | What it tells you |
|---|---|---|
| Message | `TypeError: Cannot set properties of null (setting 'textContent')` | What went wrong. `null` means "nothing was found". |
| File | `script.js` | Which file the problem is in. |
| Line | `:5` | Which line. The Console shows `script.js:5:23`: line 5. |

A red error is not a failure of yours. It is the page telling you exactly where to look.

Some mistakes show **no** red line at all. If a click does nothing and the Console is empty, check the card "Five silent faults".

## 4. View Source or Elements?

| | Ctrl + U (View Source) | Elements tab (DevTools) |
|---|---|---|
| Shows | The **file** exactly as it was sent | The **tree** the browser built from it |
| Changes when a script runs? | **No** | **Yes** |
| After a refresh | Same | Rebuilt from the file; script changes are gone |

Example: set the heading with `document.querySelector("h1").textContent = "Today's Menu"`. The page changes and Elements shows it. Ctrl + U still says *Our Menu*. Refresh, and the page says *Our Menu* again.

## 5. Why this matters for a business

Anything a script does lives in this one browser tab. Another visitor never sees it, and a refresh erases it. That is why a booking cannot be "saved" by a page alone: it needs a server (Week 8).
