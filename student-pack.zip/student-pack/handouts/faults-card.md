# Five silent faults

Most of these show **nothing wrong on the page**. Open the Console (F12) and look.

| # | Fault | What you see | What the Console says | Fix |
|---|---|---|---|---|
| 1 | **Wrong `src`** — `src="scripts.js"` | The page looks perfect; nothing happens | One red *not found* line (`ERR_FILE_NOT_FOUND`) | Match the file name exactly, in lowercase |
| 2 | **No `defer`** | The header keeps its HTML default, e.g. *Open daily, 11:00–22:00* | `TypeError: Cannot set properties of null` — `null` means "nothing found yet" | Add `defer` to the script tag |
| 3 | **Brackets in a listener** — `showSeatingNote()` | Clicking does nothing | **Nothing at all** | Name the function: `showSeatingNote` |
| 4 | **No `return`** in a function | The function answers `undefined`; an `if` using it never acts | Nothing, or a wrong message | End the function with `return` and a value |
| 5 | **Text compared as text** — `"10" > "8"` | A party of 10 is not stopped; a total comes out as `"21"` | **Nothing at all** | `Number(partyInput.value)` the moment you read it |

## Reading order when something does not work

1. Open the Console. Is there a red line? Read message, file, line.
2. No red line? Click the thing again. Does the Console show anything?
3. Is the file loaded? Check the `src` spelling and that the script tag is in the head with `defer`.
4. Is the value text? Type `typeof` before it in the Console.
