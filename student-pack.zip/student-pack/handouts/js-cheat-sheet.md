# JavaScript cheat sheet — Week 5

You will read more code than you write. This is everything the course uses. Every example is from the Little Lemon site.

## What each piece does

| Piece | What it does | Little Lemon example |
|---|---|---|
| `const` | A name for a value that will not change | `const restaurant = "Little Lemon";` |
| `let` | A name for a value that will change | `let guests = 4;` |
| String | Text, in double quotes | `"Open now"` |
| Number | No quotes, so you can calculate | `22` |
| Boolean | Only `true` or `false` | `11 < 22` |
| Array | A list, in order. Counting starts at 0 | `dishes[0]` is the first dish; `dishes.length` is `2` |
| Object | Named values, read with a dot | `dishes[0].name` is `"Falafel"` |
| Compare | `>` `<` `>=` `===` `!==` | `hour >= 11` |
| And | `&&` — both must be true | `hour >= 11 && hour < 22` |
| `if / else if / else` | Choose what happens | `if (isOpen(hourNow)) { … } else { … }` |
| `for … of` | Do something for every item | `for (const dish of dishes) { … }` |
| Function | A named rule: parameters in, `return` out | `function needsPhoneCall(party) { return party > 8; }` |
| `Number()` | Turn text into a number | `Number(partyInput.value)` |
| `document.querySelector("#id")` | Find the first element, with a CSS selector | `document.querySelector("#open-status")` |
| `.textContent` | Read or set an element's text | `openStatus.textContent = "Open now";` |
| `.classList.add("name")` | Give an element a class; CSS does the look | `openStatus.classList.add("open");` |
| `.hidden` | Show or hide an element | `seatingNote.hidden = false;` |
| `.value` / `.checked` | What a visitor typed / whether a radio is chosen | `outdoorInput.checked` |
| `createElement` and `append` | Build an element and put it on the page | `card.append(photo, name);` |
| `new Date().getHours()` | The hour on the visitor's clock | `const hourNow = new Date().getHours();` |

## The three events

An event listener says "when this happens, run this function".

| Event | Happens when | Example |
|---|---|---|
| `click` | A visitor clicks | `outdoorInput.addEventListener("click", showSeatingNote);` |
| `input` | The text in a box changes (every key) | `requestsInput.addEventListener("input", updateCount);` |
| `submit` | A visitor presses the form's submit button | `form.addEventListener("submit", checkBooking);` |

**Name the function, do not call it.** Write `showSeatingNote`, not `showSeatingNote()`. With brackets it runs once, right now, and then never when someone clicks.

## The plus trap

| Line | Answer |
|---|---|
| `4 + 2` | `6` |
| `"4" + 2` | `'42'` — text is joined, not added |
| `Number("4") + 2` | `6` |

Everything typed into a form arrives as **text**, even in a number box. Convert form values with `Number()` the moment you read them.

## Where to put the script

In the head, after the stylesheet link, always with `defer`:

```
<script src="script.js" defer></script>
```

`defer` means "wait until the whole page is read, then run".

## Questions to ask a vendor

- "Where is the form checked?" — in the browser, on the server, or both?
- "Where is the booking stored?" — a page alone cannot store it.
- "Where is the secret code kept?" — anything in browser code can be read by every visitor.
