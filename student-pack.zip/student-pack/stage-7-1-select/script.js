/* stage 7·1 · slide: s2-modify · indicators 3, 4 · end state */
/* script.js — runs on every page */

const openStatus = document.querySelector("#open-status");

openStatus.textContent = "Open now";
openStatus.classList.add("open");
