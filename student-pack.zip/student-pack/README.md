# Little Lemon · Week 5 files

DG234507 Pemrograman Web dan Mobile · Week 5: JavaScript and the DOM

Every folder here is a complete copy of the Little Lemon site. Open any page by double-clicking it; no installation is needed. Press **F12** and click **Console** to see what the scripts say.

## How the folders work

- **`stage-…` folders** are the site at each step of the lecture, in order. Each one is the folder before it plus one change. If you get lost in class, open the next stage and carry on from there.
- **`variants/`** are copies with **one thing broken or changed on purpose**. The first line of the changed file says what and why. Never copy them into your own site.
- **`console/`** holds the lines typed into the Console in class, with the answer beside each one. They are not loaded by any page.
- **`activity-1-starter/`, `activity-2-starter/`** are your starting points for the two activities.
- **`handouts/`** are three one-page guides: the Console, a cheat sheet, and five silent faults.

## Slide by slide

| Slide | Part | Open | Try this |
|---|---|---|---|
| 4 | Opening | `stage-6-styled/book.html` | Fill the form, press **Book a table**. Where did the booking go? |
| 7 | 1 · The third language | any page of `stage-6-styled` + `console/s1-console-tour.js` | Values, types, `const` and `let` in the Console |
| 8 | 1 | same | `4 + 2`, `"4" + 2`, `Number("4") + 2` |
| 9 | 1 | `stage-7-0-attach` | Console says *script.js is connected* on all three pages |
| 9 | 1 | `variants/s1-attach-fault-wrong-src` | Page looks fine; one red line in the Console |
| 11 | 2 · The page is a tree | `stage-7-0-attach` | Type `document` in the Console and open it up |
| 12–13 | 2 | `stage-7-0-attach` + `console/s2-tree-console.js` | Change the heading from the Console; compare Ctrl+U and Elements; find elements |
| 14 | 2 | `stage-7-1-select` | The header says *Open now* |
| 15 | 2 | `variants/s2-modify-fault-no-defer` | No `defer`: a red TypeError, and the header keeps its HTML text |
| 16 | 2 | `stage-7-1-select` | It says *Open now* even at 23:00. Why? |
| 18 | 3 · A rule | `stage-7-2-rule` | `isOpen(10)`, `isOpen(11)`, `isOpen(22)` in the Console |
| 18 | 3 | `variants/s3-rule-try-hour-23` | Change 23 to 10, 11, 21, 22. Predict first |
| 19 | 3 | `stage-7-2-rule` | The edges of the rule |
| 20 | Activity 1 | `activity-1-starter` | Write three rules as functions |
| 24 | 4 · Events | `stage-7-3-events/book.html` | Click Outdoor, then Indoor |
| 25 | 4 | `stage-7-3-events/book.html` | Type in Special requests; watch the count |
| 26 | 4 | `variants/s4-events-fault-called-now` | Clicking does nothing, and no error. Why? |
| 28 | 5 · Checking the booking | `stage-7-4-validate/book.html` | Choose Time 10:00. The browser refuses before any script runs |
| 29 | 5 | `stage-7-4-validate/book.html` | Book for yesterday; then a party of 10 |
| 30 | 5 | `stage-7-4-validate/book.html` + `console/s5-check-console.js` | Type 10 in Party size, then ask the Console what it is |
| 31 | 5 | `stage-7-4-validate/book.html` | Both messages, then one valid booking |
| 32 | 5 | `stage-7-4-validate` and `variants/s5-courtesy-no-script` | Delete `required` in Elements; book yesterday without the script |
| 33 | Activity 2 | `activity-2-starter` | Guard the form, then break your partner's |
| 35 | 6 · The menu as data | `stage-7-5a-data` + `console/s6-data-console.js` | `dishes`, `dishes.length`, `dishes[0].name` in the Console |
| 36–37 | 6 | `stage-7-5a-data` | Read `menu.js`: one function per card, one loop for all of them |
| 38 | 6 | `stage-7-5b-dish` | A third dish, added as data only |
| 40 | 7 · The ceiling | `variants/s7-ceiling-pretend` + `console/s7-ceiling-console.js` | It says *booked*. Refresh. Where is the booking now? |
| 41 | 7 | `variants/s7-cannot-exhibit-voucher/voucher.js` | A "secret" anyone can read |

Activity answers are handed out after each activity.
