/* console crib · slide: s5-string · indicators 1, 6 · typed live in the Console of
   stage-7-4-validate/book.html after typing 10 into Party size. Not loaded by any page. */

partyInput.value                  /* '10'  — quotes: it is text, even in a number box */
typeof partyInput.value           /* 'string' */
partyInput.value > 8              /* true  — JavaScript converted it for you, this time */
"10" > "8"                        /* false — two texts compare letter by letter: "1" comes before "8" */
Number(partyInput.value)          /* 10    — the number. book.js converts the moment it reads. */
isPastDate("2020-01-01")          /* true  — the functions in book.js can be called from here too */
needsPhoneCall(9)                 /* true */
