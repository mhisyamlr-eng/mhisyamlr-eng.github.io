/* console crib · slide: s7-ceiling · indicator 8 · typed live in the Console of
   variants/s7-ceiling-pretend/book.html after a "successful" booking. Not loaded by any page. */

formMessage.textContent           /* 'Thank you, Ana. Your table for 4 … is booked.' */
/* Refresh. Ask: where is Ana's booking now? Open the same page on a phone. Ask again. */

isOpen(23)                        /* false — and on a visitor whose laptop clock is wrong? */
hourNow                           /* whatever THIS laptop says. The badge trusts the visitor's clock. */
