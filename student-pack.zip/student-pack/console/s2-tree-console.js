/* console crib · slide: s2-tree · indicators 3, 4 · typed live in the Console of
   stage-7-0-attach/index.html. Not loaded by any page. */

document                                        /* the whole tree — expand it: html, head, body */
document.querySelector("h1")                    /* <h1>Our Menu</h1> — hover it: the page lights up */
document.querySelector("#tagline")              /* the same selectors as style.css */
document.querySelectorAll(".dish")              /* NodeList(2) — every match, not just the first */
document.querySelectorAll(".dish").length       /* 2 */

document.querySelector("h1").textContent                    /* 'Our Menu' */
document.querySelector("h1").textContent = "Today's Menu"   /* the heading changes on screen */
/* Now press Ctrl+U (View Source): the source still says Our Menu. Refresh: the change is gone.
   The DOM is the live copy in this tab; the file on the server never changed. */

document.querySelector("#tagline").classList.add("price")   /* the tagline turns amber, bold: CSS still does the look */
document.querySelector("#opening-hours")                    /* null — no element has that id. Remember this word:
                                                               it returns in the defer fault (slide s2-defer). */
